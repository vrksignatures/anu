# ProGuard rules for AniWave Mobile
