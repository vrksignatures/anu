package com.vrksignatures.aniwave;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "https://aniwaves.tv/";
    private static final String PREFS_NAME = "AniWavePrefs";

    private WebView webView;
    private ProgressBar progressBar;
    private LinearLayout myListContainer;
    private LinearLayout settingsContainer;
    private ListView listViewMyList;
    private TextView btnExoPlay;
    private TextView btnBookmarkCurrent;
    private Switch switchAutoExo;

    private SharedPreferences prefs;
    private String detectedStreamUrl = null;
    private String lastLaunchedStream = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        myListContainer = findViewById(R.id.myListContainer);
        settingsContainer = findViewById(R.id.settingsContainer);
        listViewMyList = findViewById(R.id.listViewMyList);
        btnExoPlay = findViewById(R.id.btnExoPlay);
        btnBookmarkCurrent = findViewById(R.id.btnBookmarkCurrent);
        switchAutoExo = findViewById(R.id.switchAutoExo);
        Button btnClearCache = findViewById(R.id.btnClearCache);
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);

        switchAutoExo.setChecked(prefs.getBoolean("auto_exo", true));
        switchAutoExo.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefs.edit().putBoolean("auto_exo", isChecked).apply());

        setupWebView();

        btnExoPlay.setOnClickListener(v -> {
            if (detectedStreamUrl != null) {
                launchExoPlayer(detectedStreamUrl);
            }
        });

        btnBookmarkCurrent.setOnClickListener(v -> saveCurrentToMyList());

        btnClearCache.setOnClickListener(v -> {
            webView.clearCache(true);
            CookieManager.getInstance().removeAllCookies(null);
            Toast.makeText(this, "Cache & Cookies cleared", Toast.LENGTH_SHORT).show();
        });

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                showWebView();
                webView.loadUrl(BASE_URL);
                return true;
            } else if (id == R.id.nav_search) {
                showWebView();
                webView.loadUrl(BASE_URL + "filter");
                return true;
            } else if (id == R.id.nav_mylist) {
                showMyList();
                return true;
            } else if (id == R.id.nav_settings) {
                showSettings();
                return true;
            }
            return false;
        });

        webView.loadUrl(BASE_URL);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                detectedStreamUrl = null;
                btnExoPlay.setVisibility(View.GONE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                view.evaluateJavascript(
                        "(function(){ var ads = document.querySelectorAll('iframe[src*=ad], .ad-banner, .ads, #ads'); ads.forEach(function(e){ e.remove(); }); })();",
                        null
                );
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (AdBlocker.isAdUrl(url)) {
                    return true;
                }
                if (url.contains("aniwaves.tv") || url.contains("vidplay") || url.contains("megacloud") || url.contains("filemoon")) {
                    return false;
                }
                return true;
            }

            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();

                if (AdBlocker.isAdUrl(url)) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream("".getBytes()));
                }

                if (AdBlocker.isStreamUrl(url)) {
                    detectedStreamUrl = url;
                    runOnUiThread(() -> {
                        btnExoPlay.setVisibility(View.VISIBLE);
                        if (prefs.getBoolean("auto_exo", true) && !url.equals(lastLaunchedStream)) {
                            lastLaunchedStream = url;
                            launchExoPlayer(url);
                        }
                    });
                }
                return super.shouldInterceptRequest(view, request);
            }
        });
    }

    private void launchExoPlayer(String streamUrl) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("STREAM_URL", streamUrl);
        intent.putExtra("REFERER", webView.getUrl() != null ? webView.getUrl() : BASE_URL);
        intent.putExtra("TITLE", webView.getTitle() != null ? webView.getTitle() : "AniWave Player");
        startActivity(intent);
    }

    private void saveCurrentToMyList() {
        String title = webView.getTitle();
        String url = webView.getUrl();
        if (url == null || url.isEmpty()) return;
        if (title == null || title.isEmpty()) title = url;

        Set<String> saved = new HashSet<>(prefs.getStringSet("my_list", new HashSet<>()));
        saved.add(title + "|||" + url);
        prefs.edit().putStringSet("my_list", saved).apply();
        Toast.makeText(this, "Added to My List", Toast.LENGTH_SHORT).show();
    }

    private void showWebView() {
        myListContainer.setVisibility(View.GONE);
        settingsContainer.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
    }

    private void showMyList() {
        webView.setVisibility(View.GONE);
        settingsContainer.setVisibility(View.GONE);
        myListContainer.setVisibility(View.VISIBLE);

        Set<String> saved = prefs.getStringSet("my_list", new HashSet<>());
        List<String> titles = new ArrayList<>();
        List<String> urls = new ArrayList<>();
        for (String entry : saved) {
            String[] parts = entry.split("\\|\\|\\|");
            if (parts.length == 2) {
                titles.add(parts[0]);
                urls.add(parts[1]);
            }
        }

        if (titles.isEmpty()) {
            titles.add("No saved anime yet. Tap '+ My List' on any anime page.");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_my_list, titles);
        listViewMyList.setAdapter(adapter);
        listViewMyList.setOnItemClickListener((parent, view, position, id) -> {
            if (position < urls.size()) {
                showWebView();
                webView.loadUrl(urls.get(position));
            }
        });
    }

    private void showSettings() {
        webView.setVisibility(View.GONE);
        myListContainer.setVisibility(View.GONE);
        settingsContainer.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (myListContainer.getVisibility() == View.VISIBLE || settingsContainer.getVisibility() == View.VISIBLE) {
            showWebView();
        } else if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
